> 현재, 출판된 책 내용의 **일부 소스 코드 속 콜론(:)** 이 누락되었습니다. <br>
> 확인 결과, 편집 과정 중 발생한 오류였으며 다음번 인쇄에 수정 예정입니다. <br>
> 독자분들께서는 책 속 코드를 직접 타이핑 하시기보단 현재 저장소에 저장된 코드를 참고하시길 바랍니다. 
> 불편을 드려 대단히 죄송합니다. 

# DeepLearning101
- Python, Deep Learning, PyTorch




# Authors
### 이경택 
- e-mail : lgt5512@naver.com
- github : https://github.com/LeeGyeongTak
- blog : https://bluediary8.tistory.com

### 방성수
- e-mail : twilight057@gmail.com
- github : https://github.com/8a496b

### 안상준
- e-mail : justin_a@yonsei.ac.kr
- github : https://github.com/Justin-A

![Image01](https://user-images.githubusercontent.com/35527874/95832687-9a89f800-0d75-11eb-9866-d1067e594a78.jpg)
![Image02](https://user-images.githubusercontent.com/35527874/95832694-9e1d7f00-0d75-11eb-9705-a066dd48687c.jpg)
![Image03](https://user-images.githubusercontent.com/35527874/95832700-9fe74280-0d75-11eb-8418-34f5aef31b8a.jpg)
![Image04](https://user-images.githubusercontent.com/35527874/95832706-a1b10600-0d75-11eb-856a-8f10e192749a.jpg)
![Image05](https://user-images.githubusercontent.com/35527874/95832713-a2e23300-0d75-11eb-971e-8409fced8707.jpg)
![Image06](https://user-images.githubusercontent.com/35527874/95832720-a4abf680-0d75-11eb-93e3-03c8408eb658.jpg)
